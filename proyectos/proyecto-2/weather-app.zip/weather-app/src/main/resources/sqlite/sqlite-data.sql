insert into forecast(country_name, city_name, zip_code, forecast_date, temperature) values ('Costa Rica', 'Limón', '50601', '2023-08-26 00:00:00', 23.1);
insert into forecast(country_name, city_name, zip_code, forecast_date, temperature) values ('Costa Rica', 'Alajuela', '50602', '2023-08-26 00:00:00', 24.1);
insert into forecast(country_name, city_name, zip_code, forecast_date, temperature) values ('Costa Rica', 'Heredia', '50603', '2023-08-26 00:00:00', 24.0);
